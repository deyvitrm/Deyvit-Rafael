#include<iostream>
using namespace std;
int main()
{
    float r,h;
    r=5;
    h=12;
    cout<<"VOLUMEN:"<<endl;
    cout<<(2*r*r*r+r*r*h)/3;
    cout<<"π";
    return 0;   
}