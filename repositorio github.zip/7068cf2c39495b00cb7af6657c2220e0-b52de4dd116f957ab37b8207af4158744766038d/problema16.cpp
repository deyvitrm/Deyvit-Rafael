#include<iostream>
using namespace std;
int main()
{
    int a;
    a=2;
    cout<<"AREA:"<<endl;
    cout<<2*a*a;
    cout<<"(π-2)";
    return 0; 
}