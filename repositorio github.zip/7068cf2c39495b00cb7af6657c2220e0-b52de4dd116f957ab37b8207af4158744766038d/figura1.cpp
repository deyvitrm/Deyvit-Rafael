#include <iostream>
using namespace std;
int main()
{
    cout << " Figura 1 " << endl;
    int n = 4;
    for (int i = 1; i <= n; i++) 
    {
        for (int j = 1; j <= n; j++) 
        {
            cout << "* ";
        }
        cout << endl;
    }
    cout << endl;
  return 0;
}