#include<iostream>
using namespace std;
int main ()
{
    int a,b,c;
    a=15;
    b=3;
    c=25;
    cout<<"4/4 DE VOLUMEN:"<<endl;
    cout<<(a*b*c*4)/5;
    return 0; 
}