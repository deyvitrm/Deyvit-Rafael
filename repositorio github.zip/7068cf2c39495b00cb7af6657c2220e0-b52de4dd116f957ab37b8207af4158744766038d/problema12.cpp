#include<iostream>
using namespace std;
int main()
{
    int h,r;
    h=6;
    r=3;
    cout<<"VOLUMEN:"<<endl;
    cout<<r*r*h;
    cout<<"π";
    return 0;
}