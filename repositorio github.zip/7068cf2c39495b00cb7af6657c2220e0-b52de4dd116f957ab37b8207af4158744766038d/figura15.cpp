using namespace std;
int main()
{
    cout << " Figura 15 " << endl;
    int n = 5;
    for (int i = 1; i <= n; i++) 
    {
        for (int j = 1; j <= n; j++) 
        {
            if (j == i || j == (n + 1 - i)) 
            {
                cout << "* ";
            } else {
                cout << "  ";
            }
        }
        cout << endl;
    }
    cout << endl;
    return 0;
}