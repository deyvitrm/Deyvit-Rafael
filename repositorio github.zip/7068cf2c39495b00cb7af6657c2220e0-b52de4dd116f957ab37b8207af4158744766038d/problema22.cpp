#include<iostream>
using namespace std;
int main()
{
    int r,R,H;
    r=3;
    R=6;
    H=15;
    cout<<"VOLUMEN:"<<endl;
    cout<<(H/3)*(R*R+r*r+r*R);
    cout<<"π";
    return 0;   
}